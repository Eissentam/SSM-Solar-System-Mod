//by Eissentam
//mars-resources.js
//此js用于导出火星所有方块，供科技树及其他模块引用

function getBlock(name){
    try{
        // 1) 优先尝试脚本导出（若有对应脚本）
        try{
            var modBlock = require("blocks/" + name);
            if(modBlock){
                // 若脚本直接导出同名属性（exports.远征一号 = 远征一号）
                if(modBlock[name]) return modBlock[name];
                // 或导出默认对象
                var keys = Object.keys(modBlock);
                if(keys.length === 1) return modBlock[keys[0]];
            }
        }catch(e){
            // ignore
        }

        // 2) 回退到 content 查找（兼容 JSON 定义）
        var ContentType = Java.type ? Java.type("mindustry.ctype.ContentType") : null;
        if(ContentType){
            var block = Vars.content.getByName(ContentType.block, "太阳系模组-" + name);
            if(block) return block;
        }

        // 3) 最后遍历所有 block 名称匹配（宽松匹配）
        var found = Vars.content.blocks().find(function(b){
            return b.name === "太阳系模组-" + name || b.name === name || (b.localizedName && b.localizedName === name);
        });
        return found || null;
    }catch(e){
        return null;
    }
}

// 电力相关
exports.核聚变反应堆 = getBlock("核聚变反应堆");
exports.太阳能板 = getBlock("太阳能板");
exports.探照灯 = getBlock("探照灯");
exports.微波发电机 = getBlock("微波发电机");

// 核心
exports.远征一号 = getBlock("远征一号");

// 矿物
exports.硅矿 = getBlock("硅矿");
exports.石墨矿 = getBlock("石墨矿");

// 炮塔
exports.小钢炮 = getBlock("小钢炮");

// 墙
exports.大型精炼钢墙 = getBlock("大型精炼钢墙");
exports.大型土钢墙 = getBlock("大型土钢墙");
exports.精炼钢墙 = getBlock("精炼钢墙");
exports.土钢墙 = getBlock("土钢墙");

// 生产
exports.精炼钢厂 = getBlock("精炼钢厂");
exports.游离粒子捕捉器 = getBlock("游离粒子捕捉器");

// 液体
exports.绝热装甲导管 = getBlock("绝热装甲导管");

// 运输
exports.铅传送带 = getBlock("铅传送带");
exports.土钢传送带 = getBlock("土钢传送带");
exports.土钢路由器 = getBlock("土钢路由器");

// 钻头
exports.热力钻头 = getBlock("热力钻头");