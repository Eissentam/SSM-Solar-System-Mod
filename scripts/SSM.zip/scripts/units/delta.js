//别看了，烂尾了
/*
const MarsResources = require("mars-resources");

const 德尔塔 = extend(FlyingUnit, "delta", {
    // 基础属性
    speed: 2.4,
    drag: 0.1,
    accel: 0.05,
    rotateSpeed: 6,
    hitSize: 6,
    ammoCapacity: 400,
    flying: true,
    canHeal: true,
    itemCapacity: 40,
    buildSpeed: 1.5,
    mineSpeed: 1.2,
    mineTier: 6,
    health: 600,
    faceTarget: false,
    armor: 5,
    alternate: false,
    
    // 弹药类型 - 使用火星资源
    ammoType: MarsResources.熔岩矿 || Items.blastCompound, // 后备使用爆炸化合物
    
    // 作为核心单位的特殊设置
    isCounted: false, // 不被计入单位计数
    alwaysUnlocked: true, // 始终解锁
    logicControllable: false, // 不可被逻辑控制
    
    init() {
        this.super$init();
    },
    
    draw() {
        this.super$draw();
    },
    
    update() {
        this.super$update();
    },
    
    // 修正：单位死亡时的行为
    killed() {
        // 核心单位死亡时，玩家会回到核心建筑重生
        // 只有核心建筑被摧毁才会导致游戏结束
        this.super$killed();
        
        // 如果这是玩家控制的单位，触发重生逻辑
        //核心单位死亡，但游戏不会结束
        //玩家会在团队的核心建筑中重生
        //可以添加死亡特效
        Fx.unitExplosion.at(this.x,this.y);
        
        if (this.isPlayer() && this.getPlayer() != null) {
            // 玩家死亡，但核心建筑还在，所以可以重生
            // 实际的重生逻辑在 CoreBlock 中处理
        }
    },
    
    // 添加：当单位被控制时的特殊逻辑
    controlled() {
        this.super$controlled();
        // 核心单位被控制时的特殊逻辑
    },
    
    // 添加：当单位被释放控制时的逻辑
    released() {
        this.super$released();
        // 核心单位被释放控制时的逻辑
    }
});

// 设置本地化名称
德尔塔.localizedName = "德尔塔";
德尔塔.description = "保护远征一号核心的专用防御单位";

// 添加力场能力
德尔塔.abilities.add(new ForceFieldAbility({
    reload: 10,
    radius: 20,
    angle: 280,
    width: 15,
    max: 8000,
    regen: 50,
    cooldown: 100,
    angleOffset: 270
}));

// 添加武器
德尔塔.weapons.add(new Weapon("蓝瑟1", {
    reload: 25,
    x: 0,
    y: -5,
    rotate: true,
    mirror: false,
    rotateSpeed: 9,
    shootSound: Sounds.railgun,
    
    bullet: extend(LaserBulletType, {
        collidesAir: true,
        damage: 95,
        speed: 0,
        lifetime: 24,
        smokeEffect: Fx.none,
        width: 6,
        length: 250,
        hitEffect: Fx.explosion,
        despawnEffect: Fx.none,
        colors: [Color.valueOf("E98E4250"), Color.valueOf("E98E42FF"), Color.valueOf("E98E4260")]
    })
}));

// 导出单位
exports.德尔塔 = 德尔塔;*/