try {
    const mars = require("planet/mars");
    const MarsBlocks = require("mars-resources");

    try {
        var TT = (typeof TechTree !== "undefined") ? TechTree : (typeof Java !== "undefined" ? Java.type("mindustry.content.TechTree") : null);
        if (!TT) throw "无法获取 TechTree。";

        var javaContent = MarsBlocks.远征一号;
        if(!javaContent) throw "未能找到远征一号方块。";

        mars.techTree = TT.nodeRoot("火星科技", javaContent, false, function () {
            // 第一条线：矿物开采
            if(MarsBlocks.热力钻头) { 
                TT.nodeProduce(MarsBlocks.热力钻头, function(){});
            }
            
            // 第二条线：生产
            if(MarsBlocks.精炼钢厂) {
                TT.nodeProduce(MarsBlocks.精炼钢厂, function(){ 
                    if(MarsBlocks.游离粒子捕捉器) {
                        TT.nodeProduce(MarsBlocks.游离粒子捕捉器, function(){});
                    }
                });
            }

            // 第三条线：电力
            if(MarsBlocks.太阳能板) {
                TT.nodeProduce(MarsBlocks.太阳能板, function(){ 
                    if(MarsBlocks.微波发电机) {
                        TT.nodeProduce(MarsBlocks.微波发电机, function(){
                            if(MarsBlocks.核聚变反应堆) {
                                TT.nodeProduce(MarsBlocks.核聚变反应堆, function(){});
                            }
                        });
                    }
                });
            }

            // 第四条线：运输与防御
            if(MarsBlocks.土钢传送带) {
                TT.nodeProduce(MarsBlocks.土钢传送带, function(){ 
                    if(MarsBlocks.土钢路由器) {
                        TT.nodeProduce(MarsBlocks.土钢路由器, function(){
                            if(MarsBlocks.土钢墙) {
                                TT.nodeProduce(MarsBlocks.土钢墙, function(){
                                    if(MarsBlocks.小钢炮) {
                                        TT.nodeProduce(MarsBlocks.小钢炮, function(){});
                                    }
                                });
                            }
                        });
                    }
                });
            }
        });

        print("火星科技树已生成");
    } catch (e) {
        print("火星科技树构建异常: " + e);
    }

    exports.marsTechTree = mars.techTree;
} catch (err) {
    print("火星模块加载失败: " + err);
}
